# Independent explicit-block audit of four MM discrepancies

The audit read the original downloaded arXiv v2 HTML table cells directly, hard-coded their seed exponent tuples independently of the extraction parser, built the explicit t=4 middle Koszul block matrices, and tested the physical-coordinate witnesses saved in local.json. No distance searches were run.

Qubit block order is (01,02,03,12,13,23). With multiplication matrices F,G,H,I, the explicit check blocks are:

```
HX = [G H I 0 0 0; F 0 0 H I 0; 0 F 0 G 0 I; 0 0 F 0 G H]
HZ = [Ht Gt 0 Ft 0 0; It 0 Gt 0 Ft 0; 0 It Ht 0 0 Ft; 0 0 0 It Ht Gt]
```

Here t means transpose. Multiplication block rows shift by minus the monomial exponent; transposed rows shift by plus. This construction does not enumerate exterior subsets or call the generic MM builder.

## mm_t6_r1_156_6_10

Source: v2 Appendix F Table 6, data row 1. Raw cells:

['[[156,6,(10,10)]]', '26', '0.04', '1+w^{16}', '1+w^{19}', '1+w^{22}', '1+w^{22}']

Independent reconstruction: n=156, k=6; CSS passed; HX/HZ rows match registry byte-for-byte.

Basis Z: weight 6, zero syndrome, outside the stabilizer row space. Support: [0, 4, 8, 22, 90, 116].
Basis X: weight 6, zero syndrome, outside the stabilizer row space. Support: [26, 52, 134, 138, 142, 146].

## mm_t6_r32_336_6_14

Source: v2 Appendix F Table 6, data row 32. Raw cells:

['[[336,6,(14,14)]]', '56', '0.02', '1+w^{13}', '1+w^{41}', '1+w^{49}', '1+w^{43}']

Independent reconstruction: n=336, k=6; CSS passed; HX/HZ rows match registry byte-for-byte.

Basis Z: weight 6, zero syndrome, outside the stabilizer row space. Support: [56, 97, 196, 209, 293, 334].
Basis X: weight 6, zero syndrome, outside the stabilizer row space. Support: [0, 15, 140, 153, 237, 252].

## mm_t2_r27_576_6_16

Source: v2 Appendix F Table 2, data row 27. Raw cells:

['[[576,6,(16,16)]]', '(2, 2, 3, 8)', '0.01', '2.7', 'wy^{2}+z^{6}', 'wy^{2}z^{3}+1', 'wxy^{2}+wyz^{6}', 'wxy^{2}+wyz^{6}']

Independent reconstruction: n=576, k=6; CSS passed; HX/HZ rows match registry byte-for-byte.

Basis Z: weight 6, zero syndrome, outside the stabilizer row space. Support: [0, 34, 332, 374, 428, 470].
Basis X: weight 6, zero syndrome, outside the stabilizer row space. Support: [96, 158, 192, 254, 490, 524].

## mm_t2_r33_624_12_14

Source: v2 Appendix F Table 2, data row 33. Raw cells:

['[[624,12,(14,14)]]', '(2, 2, 2, 13)', '0.02', '3.8', 'wyz^{12}+xz^{7}', 'wz^{9}+wz', 'xz^{1}1+yz^{8}', 'wxyz^{3}+xyz^{4}']

Independent reconstruction: n=624, k=12; CSS passed; HX/HZ rows match registry byte-for-byte.

Basis Z: weight 10, zero syndrome, outside the stabilizer row space. Support: [104, 109, 223, 231, 336, 393, 424, 507, 547, 555].
Basis X: weight 10, zero syndrome, outside the stabilizer row space. Support: [0, 5, 117, 187, 218, 304, 406, 414, 432, 437].

## Interpretation

No d_X/d_Z parsing error or generic-builder convention error was found. The two cyclic rows are plainly labelled (10,10) and (14,14), and the two Table 2 rows are labelled (16,16) and (14,14). The root search certificates themselves were not re-run, but each upper-bound witness independently proves a nontrivial logical at the reported smaller weight.

Table 6 row 1 repeats H=I=1+w^22; Table 2 row 27 repeats H=I=wxy^2+wyz^6. Both repetitions occur in the original HTML rather than being introduced by extraction. They may be paper seed typos; the audit retains them literally.

Table 6 row 32 is unambiguous: periods 56 and exponents (13,41,49,43), all distinct. Its weight-6 logical discrepancy is not explained by a repeated polynomial.

Table 2 row 33 prints xz^{1}1+yz^8. This audit proves distance <=10 only for its literal xz+yz^8 reading. An intended xz^11 would define a different code, so this row should be reported as a construction ambiguity, not an unconditional contradiction of the intended code.

Source PDF rendering remained unavailable from the preceding extraction task, so claims about the original PDF typesetting are not made.

## mm_t8_r16_400_20_11

Raw source cells from v2 Appendix F Table 8, row 16:

['[[400,20,(11,11)]]', '20', '0.05', '1+u^{3}', '1+u^{7}', '1+u^{11}', '1+u^{14}', '1+u^{16}', '1+u^{19}']

An independent t=6 incidence construction used hand-written pair/triple/quadruple block labels, periods 20, and seed exponents (3,7,11,14,16,19). It matches both registry matrices byte-for-byte, passes CSS, and rebuilds (400,20).

Root basis Z witness: weight 12, zero syndrome, outside stabilizer row space. Support: [120, 127, 250, 253, 343, 346, 350, 353, 360, 367, 374, 377].
Root basis X witness: weight 12, zero syndrome, outside stabilizer row space. Support: [20, 23, 26, 33, 47, 50, 54, 57, 147, 150, 260, 273].

Independent native check at K=11, with cover=False and no symmetry rank/anchors:

```json
{
  "basis": "Z",
  "K": 11,
  "cover": false,
  "rank": null,
  "anchors": null,
  "status": "exhausted",
  "best": null,
  "seconds": 0.7822120189666748,
  "nodes": [
    0,
    400,
    691,
    2364,
    9831,
    44410,
    208730,
    1002229,
    829643,
    43491,
    0,
    0,
    0
  ],
  "solutions": [],
  "solutions_verified": []
}
```

Independent native check at K=11, with cover=False and no symmetry rank/anchors:

```json
{
  "basis": "X",
  "K": 11,
  "cover": false,
  "rank": null,
  "anchors": null,
  "status": "exhausted",
  "best": null,
  "seconds": 0.5789141654968262,
  "nodes": [
    0,
    400,
    655,
    2230,
    9541,
    44400,
    212862,
    1042802,
    732745,
    35803,
    0,
    0,
    0
  ],
  "solutions": [],
  "solutions_verified": []
}
```

This bounded check searches only K=11. An exhausted result supports absence of logical weight <=11 for this construction; a timeout gives no new lower-bound certificate. Smaller-threshold root certificates were not independently repeated.

## mm_t3_r6_324_12_20

Source: original v2 Appendix F Table 3, data row 6. Direct raw cells:

['[[324,12,(20,20)]]', '2, 3, 3, 3', '0.04', 'wx^{2}y+x^{2}y^{2}+z', 'wy+xy+y^{2}z^{2}', 'wx^{2}z+wyz+yz^{2}', 'wx^{2}y^{2}+wxyz^{2}+xy^{2}z']

The published row unambiguously gives [[324,12,(20,20)]], periods (2,3,3,3), and four three-term polynomials. All exponents are within the respective periods; no printed ambiguity or duplicate generator is present.

Hard-coded independent exponent tuples in variable order (w,x,y,z):

```
[[(1, 2, 1, 0), (0, 2, 2, 0), (0, 0, 0, 1)], [(1, 0, 1, 0), (0, 1, 1, 0), (0, 0, 2, 2)], [(1, 2, 0, 1), (1, 0, 1, 1), (0, 0, 1, 2)], [(1, 2, 2, 0), (1, 1, 1, 2), (0, 1, 2, 1)]]
```

The explicit t=4 block construction described above matches both registry matrices byte-for-byte. CSS passes; ranks are rank(HX)=156, rank(HZ)=156, giving (n,k)=(324,12). Every check has weight 9, as expected for Table 3.

Basis Z: weight-18 witness has zero syndrome and increases the relevant stabilizer rank from 156 to 157, proving a nontrivial logical. Support: [54, 58, 62, 81, 85, 89, 182, 183, 187, 209, 210, 214, 279, 283, 287, 306, 310, 314].
Basis X: weight-18 witness has zero syndrome and increases the relevant stabilizer rank from 156 to 157, proving a nontrivial logical. Support: [0, 4, 8, 27, 31, 35, 127, 131, 132, 154, 158, 159, 225, 229, 233, 252, 256, 260].

No source parsing or builder convention error was found. Both independently verified witnesses prove distance <=18 for the literal published code. The root reports exhaustion at every smaller threshold and exact distance 18 in both bases; this audit did not rerun those searches. The published randomized estimate 20 is therefore consistent with an overestimate, and the audited source contains no reason to alter the construction.
