import json,sys,time
from pathlib import Path
sys.path.insert(0,'papers');sys.path.insert(0,str(Path(__file__).parent))
import stabcode
from cdist import search,symmetry
from prototype import matrices,translations,parameters
records=json.loads((Path(__file__).parent/'codes.json').read_text());out=[]
for rec in records:
 if rec['status']!='control':continue
 hx,hz,n=matrices(rec['periods'],rec['polys'])
 lx,lz=stabcode.css_logicals(hx,hz,n)
 got={'name':rec['name'],'n':n,'k':parameters(hx,hz,n)[1],'witnesses':{},'distance':{}}
 for basis,opbasis,checks,anticomm in [('Z',lx,hz,lz),('X',lz,hx,lx)]:
  v=min(opbasis,key=lambda x:bin(x).count('1'))
  assert all(not stabcode.parity(v&r) for r in checks)
  assert any(stabcode.parity(v&r) for r in anticomm)
  assert bin(v).count('1')==rec['d_claimed']
  got['witnesses'][basis]=stabcode.bits(v)
  if n==96:
   p=stabcode.css_distance_problem(hx,hz,n,basis,name=rec['name'])
   sym=symmetry.from_row_perms(p,translations(rec['periods'],len(rec['polys'])))
   t=time.time();r=search.distance(p,k_table=2,kmax=8,cover=True,time_limit=30,rank=sym['rank'],anchors=sym['anchors'])
   got['distance'][basis]={'d':r['distance'],'lower_bound':r['lower_bound'],'runs':r['runs'],'seconds':time.time()-t,'symmetries':sym.get('n_symmetries_kept'),'witness':r['solutions'][0] if r['solutions'] else None}
   print(rec['name'],basis,'d',r['distance'],'lb',r['lower_bound'],'seconds',got['distance'][basis]['seconds'],flush=True)
 out.append(got)
(Path(__file__).parent/'controls.json').write_text(json.dumps(out,indent=2))
print('Verified stated-weight nontrivial logicals in both bases for both controls.',flush=True)
