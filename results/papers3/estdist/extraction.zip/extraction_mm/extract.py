import json,re,sys
from pathlib import Path
sys.path.insert(0,'papers');import stabcode
from prototype import polynomial,matrices,parameters
base=Path(__file__).parent
wanted={(216,12,14),(288,12,16),(324,12,20),(630,70,9),(96,12,8),(486,24,12)}
all_,bad=[],[]
for table in range(2,12):
 z=json.loads((base/f'A6.T{table}.json').read_text())
 for ix,r in enumerate(z['rows'][1:],1):
  m=re.fullmatch(r'\[\[(\d+),(\d+),\((\d+),(\d+)\)\]\]',r[0])
  if not m:continue
  n,k,dx,dz=map(int,m.groups());d=min(dx,dz)
  if n>700 or d>20:continue
  status='control' if table==5 or (table==7 and n<=290) else 'open'
  if table==4 and (n,k,d)==(486,24,12):status='control'
  if status=='control' and (n,k,d) not in wanted:continue
  periods=list(map(int,re.findall(r'\d+',r[1])))
  ps=r[-(4 if table<=6 else table-2):]
  if table<=5:vars_='wxyz'
  elif table==6:vars_='w';periods=periods[:1]
  else:vars_='rstuvwxyz'[-(table-2):];periods=periods[:1];vars_=vars_[:1]
  rec={'name':f'mm_t{table}_r{ix}_{n}_{k}_{d}','arxiv':'2601.18879','n':n,'k':k,'d_claimed':d,'d_x_claimed':dx,'d_z_claimed':dz,'status':status,'locator':f'v2 Appendix F Table {table}, data row {ix}; Eqs.67,99,100','periods':periods,'polynomial_text':ps,'variables':vars_}
  try:
   rec['polys']=[polynomial(p,vars_) for p in ps]
   hx,hz,n_=matrices(periods,rec['polys']);params=parameters(hx,hz,n_)
   rec['rebuilt_n'],rec['rebuilt_k']=params;rec['row_weights']={'X':sorted(set(bin(r).count('1') for r in hx)),'Z':sorted(set(bin(r).count('1') for r in hz))}
   if params!=(n,k):rec['parameter_mismatch']=True
   all_.append(rec)
   if (n,k,d) in wanted: print('TARGET',rec['name'],params,flush=True)
  except Exception as ex:rec['error']=str(ex);bad.append(rec)
(base/'codes.json').write_text(json.dumps(all_,indent=2))
(base/'malformed.json').write_text(json.dumps(bad,indent=2))
print('Extracted',len(all_),'malformed',len(bad))
print('Target rows')
for rec in all_:
 if (rec['n'],rec['k'],rec['d_claimed']) in wanted:print(rec['name'],rec['status'],rec['rebuilt_n'],rec['rebuilt_k'],rec['periods'],rec['polynomial_text'])
print('MISMATCHES')
for rec in all_:
 if rec.get('parameter_mismatch'):print(rec['name'],'rebuilt',rec['rebuilt_n'],rec['rebuilt_k'])
print('MALFORMED')
for rec in bad:print(rec['name'],rec['error'])
