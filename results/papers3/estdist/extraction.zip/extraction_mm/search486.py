import json,sys,time
from pathlib import Path
sys.path.insert(0,'papers');sys.path.insert(0,str(Path(__file__).parent))
import stabcode
from cdist import search,symmetry
from prototype import matrices,translations
rec=next(r for r in json.loads((Path(__file__).parent/'codes.json').read_text()) if r['name']=='mm_t4_r17_486_24_12')
hx,hz,n=matrices(rec['periods'],rec['polys']);out={}
for basis in 'ZX':
 p=stabcode.css_distance_problem(hx,hz,n,basis,name=rec['name'])
 sym=symmetry.from_row_perms(p,translations(rec['periods'],len(rec['polys'])))
 t=time.time()
 def progress(r):print(basis,'K',r['K'],'status',r.get('status'),'seconds',r.get('seconds'),'nodes',r.get('nodes'),flush=True)
 r=search.distance(p,k_table=2,kmax=12,cover=True,time_limit=60,rank=sym['rank'],anchors=sym['anchors'],on_run=progress)
 out[basis]={'d':r['distance'],'lower_bound':r['lower_bound'],'runs':r['runs'],'seconds':time.time()-t,'symmetries':sym.get('n_symmetries_kept'),'witness':r['solutions'][0] if r['solutions'] else None}
 (Path(__file__).parent/'control486_distance.json').write_text(json.dumps(out,indent=2))
 print('RESULT',basis,out[basis]['d'],out[basis]['lower_bound'],out[basis]['seconds'],flush=True)
