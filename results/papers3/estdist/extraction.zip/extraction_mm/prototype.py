"""Lightweight prototype: arXiv:2601.18879v2, Eqs.67,99,100.
Only extracted data; not downloaded executable code.
"""
import itertools, math, re

def polynomial(text, variables):
    s=re.sub(r'\s+', '', text).replace('*','')
    # Tiny parser for sums/products of monomials, no eval.
    toks=re.findall(r'[A-Za-z]|\d+|[+()^{}]', s)
    assert ''.join(toks)==s, s
    zero=(0,)*len(variables)
    at=0
    def plus(a,b): return a.symmetric_difference(b)
    def times(a,b):
        out=set()
        for x in a:
            for y in b:
                v=tuple(u+v for u,v in zip(x,y))
                if v in out: out.remove(v)
                else: out.add(v)
        return out
    def expr():
        nonlocal at
        out=product()
        while at<len(toks) and toks[at]=='+':
            at+=1;out=plus(out,product())
        return out
    def product():
        nonlocal at
        out={zero}; seen=False
        while at<len(toks) and toks[at] not in ('+',')'):
            seen=True;tok=toks[at];at+=1
            if tok=='(':
                value=expr(); assert toks[at]==')';at+=1
            elif tok=='1':value={zero}
            elif tok in variables:
                power=1
                if at<len(toks) and toks[at]=='^':
                    at+=1
                    if toks[at]=='{': at+=1;power=int(toks[at]);at+=1;assert toks[at]=='}';at+=1
                    else: power=int(toks[at]);at+=1
                v=list(zero);v[variables.index(tok)]=power;value={tuple(v)}
            else: raise ValueError('Malformed polynomial '+s+' at '+tok)
            out=times(out,value)
        assert seen
        return out
    out=expr();assert at==len(toks)
    return sorted(out)

def matrices(periods, polys):
    t=len(polys);q=t//2;s=math.prod(periods)
    points=list(itertools.product(*(range(x) for x in periods)))
    indices={p:i for i,p in enumerate(points)}
    mids=list(itertools.combinations(range(t),q))
    low=list(itertools.combinations(range(t),q-1))
    high=list(itertools.combinations(range(t),q+1))
    hx=[0]*(len(low)*s);hz=[0]*(len(high)*s)
    # Boundary: source(mid,point) -> target(mid-minus-i,point+monomial).
    for j,A in enumerate(mids):
        for v,p in enumerate(points):
            for i in A:
                a=low.index(tuple(x for x in A if x!=i))
                for exp in polys[i]:
                    w=indices[tuple((x+y)%m for x,y,m in zip(p,exp,periods))]
                    hx[a*s+w]^=1<<(j*s+v)
    for j,A in enumerate(high):
        for v,p in enumerate(points):
            for i in A:
                a=mids.index(tuple(x for x in A if x!=i))
                for exp in polys[i]:
                    w=indices[tuple((x+y)%m for x,y,m in zip(p,exp,periods))]
                    hz[j*s+v]^=1<<(a*s+w)
    return hx,hz,len(mids)*s

def translations(periods, t):
    # Odd t has different X and Z check counts: no shared check permutation.
    if t%2:return []
    q=t//2;s=math.prod(periods);count=math.comb(t,q-1)
    points=list(itertools.product(*(range(x) for x in periods)))
    inds={p:i for i,p in enumerate(points)}
    return [[j*s+inds[tuple((x+y)%m for x,y,m in zip(p,shift,periods))] for j in range(count) for p in points] for shift in points[1:]]

def parameters(hx,hz,n):
    zcols=[0]*n
    for i,r in enumerate(hz):
        while r:
            low=r&-r;zcols[low.bit_length()-1]|=1<<i;r^=low
    for r in hx:
        syndrome=0
        while r:
            low=r&-r;syndrome^=zcols[low.bit_length()-1];r^=low
        assert syndrome==0,'CSS mismatch'
    def rank(rows):
        piv={}
        for r in rows:
            while r:
                p=r.bit_length()-1
                if p not in piv:piv[p]=r;break
                r^=piv[p]
        return len(piv)
    return n,n-rank(hx)-rank(hz)
