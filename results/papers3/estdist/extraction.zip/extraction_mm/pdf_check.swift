import Foundation
import PDFKit
import AppKit
let base = URL(fileURLWithPath: CommandLine.arguments[1])
let doc = PDFDocument(url: base.appendingPathComponent("paper_v2.pdf"))!
var whole = ""
for i in 0..<doc.pageCount {
    let p = doc.page(at:i)!
    let text = p.string ?? ""
    whole += "\nPAGE \(i+1)\n" + text
    if text.contains("294,") || (text.contains("288,") && text.contains("w2y3")) {
        let image = p.thumbnail(of:NSSize(width:1400,height:2000),for:.mediaBox)
        let rep = NSBitmapImageRep(data:image.tiffRepresentation!)!
        let png = rep.representation(using:.png,properties:[:])!
        try! png.write(to:base.appendingPathComponent("page_\(i+1).png"))
        print("Rendered page",i+1)
    }
}
try! whole.write(to:base.appendingPathComponent("paper_pdf.txt"),atomically:true,encoding:.utf8)
print("Pages",doc.pageCount)
