# arXiv:2601.18879 extraction handoff

Sources read: https://arxiv.org/html/2601.18879 (v2), https://arxiv.org/html/2601.18879v1, and the v2 PDF downloaded directly from arxiv.org. No author repositories or data sets were accessed.

`codes.json` contains 214 rows: 212 open QDistRnd estimates and the two required controls. `interpreted294.json` adds one open row with an explicit missing-exponent interpretation. All 214 literal entries pass sparse CSS verification. Their n/k agree with the published table except Table 3 [[288,12,16]], which literally rebuilds [[288,0]]. The extra inferred row rebuilds [[294,6]].

## Construction and ordering

Use Eq.67 of v2: the Koszul differential removes one generator index from an exterior subset and multiplies by that generator polynomial. Qubits are lexicographically ordered q-subsets, q=floor(t/2), each with a lexicographically ordered monomial basis of Z_l1 x ... x Z_lD. Polynomials are lists of monomial exponent tuples; products add exponents modulo the periods, and duplicate terms cancel over GF(2).

The prototype uses HX as the matrix with rows on K_(q-1) and columns on K_q; HZ has rows on K_(q+1) and columns on K_q. These match the dimensions of Eqs.99–100 and Table 7's row weights (8 for X, 6 for Z). Eqs.94–95 write transposes in a way inconsistent with the displayed map arrows; follow the dimensionally valid boundary maps and CSS condition. `prototype.py` implements the builder and a fast sparse CSS/rank check.

For even t, all nonidentity translations of the monomial basis, applied identically in each exterior-subset check block, give row-permutation candidates common to HX/HZ. For odd t, HX/HZ have unequal row counts; no shared check-index permutation is returned. A driver accepting basis-specific candidates could exploit translations there, but the requested interface asks for a common permutation.

## Required rows

- [[216,12,14]]: v2 Appendix F Table 4 row 5, periods (2,2,3,3), weight 12 checks; literal reconstruction agrees.
- [[288,12,16]]: v2 Appendix F Table 3 row 5, periods (4,2,2,3); literal reconstruction gives k=0. Keep the published tuple and report mismatch; do not repair it by changing periods. The y^3 terms are legal after cyclic reduction, but the entire code has no logical qubits.
- [[324,12,20]]: v2 Appendix F Table 3 row 6, periods (2,3,3,3); literal reconstruction agrees.
- [[630,70,9]]: v2 Appendix F Table 10 row 1, t=8, periods (9,), polynomials 1+s^a for a=1,...,8; literal reconstruction agrees.
- [[96,12,8]] control: v2 Appendix F Table 5 row 2, periods (2,2,2,2). Exact search gives 8 in both bases; all 15 nonidentity translations survive.
- [[486,24,12]] control: v2 Appendix F Table 4 row 17, periods (3,3,3,3), F=1+wx+x^2y, G=1+xy+y^2z, H=1+yz+wz^2, I=1+wz+w^2x. Exact search gives 12 in both bases; all 80 nonidentity translations survive. Distinct Table 3 row 11 has the same n/k/d claim but different polynomials, and remains marked open.

Control witness coordinates are in `controls.json`. They commute with the detecting check matrix and anticommute with at least one logical of the other type. Basis Z uses an X error, basis X a Z error. Native exact-search output is also in `control486_distance.json`; each found witness passed cdist.search.verify automatically.

## Distance status and version issues

Tables 2–4, 6, 8–11 use DistRandCSS with 1000 information sets and mindist=0. Despite captions saying it returns the actual distance, this is randomized estimation; mark these open unless an instance is explicitly used as a requested exact control. Table 5 reports Gurobi MIP exact values. Table 7 is exact for n<=290, estimated for n>290; only its open portion was included. Other exact controls were omitted to reduce scope. No Table 11 row has n<=700.

V1 has only Tables 1–2 and does not define the requested estimated [[288,12,16]], [[324,12,20]], or [[630,70,9]] instances; its abstract gives [[216,12,12]] instead of the newer [[216,12,14]]. Therefore v1 cannot resolve the 288 discrepancy. V2's table locators differ from the prompt: explicit rows are in Appendix F; Appendix E uses Julia examples.

## Printed ambiguities

- Table 2 row 33 [[624,12,14]] has H=xz^{1}1+yz^8. The literal polynomial x*z^1*1+yz^8 was used and k=12 agrees. A plausible intended x*z^11 is not assumed; record the printed ambiguity.
- Table 6 row 25 [[294,6,14]] prints I=1+w48. `malformed.json` preserves the literal failed parse; `interpreted294.json` interprets this as 1+w^48 because the entire table uses binomials 1+w^a. This interpreted code passes CSS and rebuilds (294,6).

## Local computational checks

No remote jobs, installations, commits, or final shared-file edits were made. Extraction uses small local Python checks, OMP_NUM_THREADS=2. Exact controls used k_table=2 with cover=True and full translation candidates. The 96 control took 0.066s (Z) and 0.049s (X), excluding problem setup; the 486 control took 0.105s (Z) and 0.150s (X). Both reached exact stated distances. Threshold node counts are stored in JSON. The controls' node growth was tiny and gives no useful extrapolation for estimated targets with different polynomial sparsity; use the final registry driver to obtain their own threshold timings.

PDF inspection did not complete: web PDF retrieval rejected the 18.6 MB content; local download succeeded, but the system Swift/default SDK versions were incompatible. An older-SDK compile was interrupted after no result, and direct ctypes PDFKit text extraction aborted with exit 134. No PDF rendering or text extraction was verified; definitions and typo interpretations are based on the arXiv HTML.
