import ctypes as C
from pathlib import Path
C.CDLL('/System/Library/Frameworks/Foundation.framework/Foundation')
C.CDLL('/System/Library/Frameworks/PDFKit.framework/PDFKit')
objc=C.CDLL('/usr/lib/libobjc.A.dylib')
objc.objc_getClass.argtypes=[C.c_char_p];objc.objc_getClass.restype=C.c_void_p
objc.sel_registerName.argtypes=[C.c_char_p];objc.sel_registerName.restype=C.c_void_p
addr=C.cast(objc.objc_msgSend,C.c_void_p).value
ptr=C.c_void_p

def cls(s):return objc.objc_getClass(s.encode())
def call(obj,sel,*args):
 f=C.CFUNCTYPE(ptr,ptr,ptr,*([ptr]*len(args)))(addr)
 return f(obj,objc.sel_registerName(sel.encode()),*args)
pool=call(call(cls('NSAutoreleasePool'),'alloc'),'init')
path=str((Path(__file__).parent/'paper_v2.pdf').resolve()).encode()
strfn=C.CFUNCTYPE(ptr,ptr,ptr,C.c_char_p)(addr)
s=strfn(cls('NSString'),objc.sel_registerName(b'stringWithUTF8String:'),path)
url=call(cls('NSURL'),'fileURLWithPath:',s)
doc=call(call(cls('PDFDocument'),'alloc'),'initWithURL:',url)
assert doc
count=call(doc,'pageCount');print('Pages',count)
whole=[]
utf=C.CFUNCTYPE(C.c_char_p,ptr,ptr)(addr)
for i in range(count):
 p=call(doc,'pageAtIndex:',i);ss=call(p,'string');txt=utf(ss,objc.sel_registerName(b'UTF8String')).decode() if ss else ''
 whole.append(f'\nPAGE {i+1}\n'+txt)
(Path(__file__).parent/'paper_pdf.txt').write_text(''.join(whole))
call(pool,'drain')
