# arXiv:2607.27644 extraction

Source: https://arxiv.org/html/2607.27644 (v1; paper title: Quantum LDPC codes with design rate 1/5 and good performance below 1000 physical qubits).

All five requested instances are completely defined. Table 1 classifies 160/240/320 as exact and 390/550 as upper bounds. The caption says pySATDist computes exact distances and QDistEvol computes upper bounds. Table 3 supplies every seed polynomial; there is no missing external data.

Appendix A, Table 8 supplies two further eligible open instances, [[525,105,<=18]] and [[625,125,<=20]]. The [[700,140,<=22]] entry exceeds the requested distance cap. For optional extra controls, Table 8 also fully specifies [[60,12,6]], [[100,20,8]], [[150,30,10]], [[210,42,12]]. The prototype includes these optional controls but they need not be added to meet the request for additional uncertified instances.

## Construction locators

- Section 2.1, Eq. (1a,b): five-block CSS matrices.
- Section 2.2, Eq. (5): ZSZ group presentation; Eq. (6): multiplication convention.
- Section 2.4, Eq. (13): A=L[a], B=L[b], C=R[c], D=R[d].
- Table 3: parameters and a,b,c,d for 160,240,320,390,550.
- Appendix A, Table 8: parameters and a,b,c,d for 525,625 and optional 60,100,150,210 controls.
- Appendix B, Eq. (49): L[g]|h>=|gh>, R[g]|h>=|hg>, and the note that R is anti-homomorphic with no inverse in its defining action.
- Appendix C.4, preceding Eq. (83): group-element index x^a y^b maps to a*ell2+b.
- Appendix C.4.1, Table 10: u_L,v_L,u_R,v_R; rows of (L[u_L],L[v_L]) and (R[u_R],R[v_R]) give classical codewords.
- Section 3.2, Eq. (21): embed a left codeword on data blocks (1,3) for physical Z, right codeword on (1,2) for physical X.
- Appendix D.3, Eqs. (133),(134), Table 13: center action simultaneously permutes the two check blocks and five data blocks.

## Checked locally

`OMP_NUM_THREADS=2 .venv/bin/python results/papers3/estdist/extraction_balanced/prototype.py`

Passed: CSS commutation, reconstructed n/k, all check weights 9, all proposed nonidentity center row permutations accepted by cdist.symmetry.from_row_perms in both bases. The 160/240/320/390/550 Table-10 identity-row witnesses are logical operators of claimed weights 10/12/14/16/18, respectively, in both physical Pauli sectors; checked zero syndrome and nonmembership in the opposite stabilizer rowspace. This is a witness verification, not a fresh exact distance certification.

Nonidentity accepted symmetry counts (same in both bases): 160:7; 240:11; 320:1; 390:1; 550:1; 525:4; 625:4; optional controls 60:1; 100:1; 150:4; 210:6.

The first prototype run failed because this project's Python has no int.bit_count; replaced with bin(...).count('1') and reran successfully.

Driver convention reminder: stabcode.css_distance_problem(...,'Z') searches physical X operators checked by Hz; basis 'X' searches physical Z checked by Hx. Thus `paper_witnesses()['X']` embeds the left codeword and `paper_witnesses()['Z']` the right codeword.

No distance search, repository/data download, install, remote submission, or change outside this extraction directory was performed.
