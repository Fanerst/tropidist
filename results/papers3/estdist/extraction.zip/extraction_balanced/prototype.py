"""Table 3/Table 8 of arXiv:2607.27644, lightweight extraction prototype."""
import math
import os
import sys
sys.path.insert(0, os.path.abspath('.'))
from papers import stabcode
from cdist.symmetry import from_row_perms

# n,k,d,status,(ell1,ell2,q),a,b,c,d. Each monomial is (x exponent,y exponent).
PARAMS = [
 (160,32,10,'control',(16,2,9),[(0,0),(13,0),(14,1)],[(0,0),(3,1),(13,1)],[(0,0),(14,0),(12,1)],[(0,0),(7,0),(11,0)]),
 (240,48,12,'control',(12,4,7),[(0,0),(8,1),(7,2)],[(0,0),(2,0),(5,1)],[(0,0),(4,1),(2,3)],[(0,0),(4,0),(9,0)]),
 (320,64,14,'control',(16,4,3),[(0,0),(1,0),(0,1)],[(0,0),(2,0),(13,3)],[(0,0),(12,1),(2,3)],[(0,0),(12,0),(11,2)]),
 (390,78,16,'open',(26,3,3),[(0,0),(17,1),(14,2)],[(0,0),(16,0),(3,1)],[(0,0),(24,0),(8,1)],[(0,0),(21,0),(0,1)]),
 (550,110,18,'open',(22,5,3),[(0,0),(10,0),(5,2)],[(0,0),(8,0),(2,3)],[(0,0),(7,0),(16,1)],[(0,0),(1,0),(6,4)]),
 (525,105,18,'open',(35,3,11),[(0,0),(22,0),(1,2)],[(0,0),(4,0),(16,2)],[(0,0),(34,0),(12,1)],[(0,0),(28,1),(31,1)]),
 (625,125,20,'open',(25,5,6),[(0,0),(6,0),(1,1)],[(0,0),(24,1),(21,3)],[(0,0),(3,2),(11,3)],[(0,0),(4,0),(6,2)]),
 (60,12,6,'control',(3,4,2),[(0,0),(0,3),(2,3)],[(0,0),(1,0),(1,2)],[(0,0),(0,1),(1,3)],[(0,0),(0,2),(0,3)]),
 (100,20,8,'control',(5,4,4),[(0,0),(2,1),(0,3)],[(0,0),(2,0),(1,3)],[(0,0),(0,3),(4,3)],[(0,0),(4,2),(1,3)]),
 (150,30,10,'control',(15,2,11),[(0,0),(11,0),(12,1)],[(0,0),(0,1),(6,1)],[(0,0),(3,0),(11,0)],[(0,0),(6,0),(14,1)]),
 (210,42,12,'control',(21,2,8),[(0,0),(1,1),(3,1)],[(0,0),(12,0),(17,0)],[(0,0),(4,1),(15,1)],[(0,0),(9,1),(18,1)]),
]

# u_L, v_L, u_R, v_R from Table 10; use rows of L and R, not polynomial
# coefficient vectors. The identity-index row is antipode of each polynomial.
WITNESS_POLYS = {
160: (
 [(8,0),(11,0),(4,1),(8,1),(13,1)],
 [(0,0),(10,0),(15,0),(3,1),(11,1)],
 [(3,0),(8,0),(13,0),(3,1),(5,1),(7,1),(10,1)],
 [(5,0),(8,0),(10,1)]),
240: (
 [(4,0),(6,1),(8,2),(9,2),(4,3)],
 [(3,0),(4,0),(7,0),(0,1),(3,1),(8,1),(10,1)],
 [(8,0),(10,0),(11,0),(6,1),(4,2)],
 [(1,0),(6,0),(8,0),(10,0),(0,1),(1,3),(6,3)]),
320: (
 [(7,0),(0,1),(7,1),(13,1),(4,2),(7,2),(4,3),(9,3),(14,3)],
 [(0,1),(9,2),(3,3),(10,3),(13,3)],
 [(8,0),(9,0),(6,1),(2,2),(7,2),(11,2),(14,2),(11,3),(12,3)],
 [(8,0),(7,2),(12,2),(14,2),(12,3)]),
390: (
 [(1,0),(14,0),(8,1),(16,1),(24,1),(2,2),(3,2)],
 [(5,0),(7,0),(25,0),(4,1),(8,1),(12,1),(12,2),(17,2),(20,2)],
 [(8,0),(11,0),(24,0),(2,1),(23,1),(14,2),(21,2)],
 [(0,0),(3,0),(6,0),(4,1),(9,1),(13,1),(18,1),(16,2),(23,2)]),
550: (
 [(13,0),(18,1),(8,2),(10,2),(0,4),(3,4),(7,4),(11,4),(15,4)],
 [(13,0),(20,1),(5,2),(8,2),(11,2),(14,2),(17,2),(4,4),(16,4)],
 [(5,0),(12,0),(8,1),(13,1),(12,2),(17,2),(18,2),(0,3),(1,3),(7,3),(8,3)],
 [(21,0),(14,1),(15,1),(11,2),(19,2),(8,3),(17,3)]),
}

def mul(g,h,group):
    l,m,q=group
    i,j=g; a,b=h
    return ((i+pow(q,j,l)*a)%l,(j+b)%m)

def regular_rows(group,poly,side):
    l,m,q=group
    rows=[0]*(l*m)
    # Eq49 sends |h> to |g h> (L) or |h g> (R), i.e. column -> row.
    for i in range(l):
        for j in range(m):
            col=i*m+j
            for g in poly:
                a,b=mul(g,(i,j),group) if side=='L' else mul((i,j),g,group)
                rows[a*m+b] ^= 1<<col
    return rows

def transpose(rows,size):
    out=[0]*size
    for i,row in enumerate(rows):
        for j in stabcode.bits(row):
            out[j] ^= 1<<i
    return out

def matrices(entry):
    n,k,d,status,group,a,b,c,e=entry
    ell=group[0]*group[1]
    A=regular_rows(group,a,'L');B=regular_rows(group,b,'L')
    C=regular_rows(group,c,'R');D=regular_rows(group,e,'R')
    AT=transpose(A,ell);BT=transpose(B,ell)
    CT=transpose(C,ell);DT=transpose(D,ell)
    hx=[A[i] | (B[i]<<(2*ell)) | (CT[i]<<(4*ell)) for i in range(ell)]
    hx += [(A[i]<<ell) | (B[i]<<(3*ell)) | (DT[i]<<(4*ell)) for i in range(ell)]
    hz=[C[i] | (D[i]<<ell) | (AT[i]<<(4*ell)) for i in range(ell)]
    hz += [(C[i]<<(2*ell)) | (D[i]<<(3*ell)) | (BT[i]<<(4*ell)) for i in range(ell)]
    return hx,hz,5*ell

def symmetries(entry):
    group=entry[4]; l,m,q=group;ell=l*m
    t=next(t for t in range(1,m+1) if pow(q,t,l)==1)
    u=math.gcd(l,q-1)
    out=[]
    for i in range(u):
        for j in range(m//t):
            z=(i*l//u,j*t)
            if z==(0,0): continue
            p=[]
            for block in range(2):
                for a in range(l):
                    for b in range(m):
                        c,d=mul(z,(a,b),group)
                        p.append(block*ell+c*m+d)
            out.append(p)
    return out

def paper_witnesses(entry):
    n=entry[0];group=entry[4];ell=group[0]*group[1]
    u,v,r,s=WITNESS_POLYS[n]
    U=regular_rows(group,u,'L');V=regular_rows(group,v,'L')
    R=regular_rows(group,r,'R');S=regular_rows(group,s,'R')
    # Physical Z errors commute with Hx (driver memory basis X);
    # physical X errors commute with Hz (driver memory basis Z).
    return {'X': U[0] | (V[0]<<(2*ell)), 'Z': R[0] | (S[0]<<ell)}

def in_span(v,rows):
    basis,pivots=stabcode.rref(rows)
    for b,p in zip(basis,pivots):
        if v>>p&1:v^=b
    return v==0

if __name__=='__main__':
    for e in PARAMS:
        hx,hz,n=matrices(e)
        assert stabcode.css_parameters(hx,hz,n)==e[:2]
        assert set(bin(r).count('1') for r in hx+hz)=={9}
        perms=symmetries(e)
        kept=[]
        for basis in ['X','Z']:
            p=stabcode.css_distance_problem(hx,hz,n,basis)
            sym=from_row_perms(p,perms)
            assert sym['ok']
            assert sym['n_symmetries_kept']==len(perms)
            kept.append(sym['n_symmetries_kept'])
        witnesses={}
        if n in WITNESS_POLYS:
            for basis,w in paper_witnesses(e).items():
                det,stab=(hx,hz) if basis=='X' else (hz,hx)
                assert all(bin(w&r).count('1')%2==0 for r in det)
                assert not in_span(w,stab)
                assert bin(w).count('1')==e[2]
                witnesses[basis]=stabcode.bits(w)
        print({'n':n,'k':e[1],'status':e[3],'CSS':True,'check_weights':[9],
               'symmetries_kept_X_Z':kept,'paper_witnesses':witnesses})
