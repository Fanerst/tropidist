# QGPU and LLM extraction

Sources read only from https://arxiv.org/pdf/2603.05398 and https://arxiv.org/html/2606.02418. No author repositories or datasets were read or executed.

## QGPU 2603.05398

Complete seeds are in Appendix H, Tables VI (k=8) and VII (k=18), PDF p.25, not Appendix F. Table I p.7 lists parameters. Appendix F Table IV p.23 says all ten code distances, including [[24,8,3]], are QDistRnd estimates. The requested [[24,8,3]] is marked control following the task's explicit classification; this contradicts the paper's uniform estimation methodology and should be noted.

`codes.json` contains the exact seed polynomial entries. Each entry `[e,f]` means x^e+x^f, and `[]` means zero. These include every Table I CC code: [[24,8,3]], [[40,8,5]], [[56,8,7]], [[88,8,10]], [[104,8,11]], [[136,8,14]], [[54,18,3]], [[90,18,5]], [[126,18,7]], [[198,18,10]]. All have n<=700,d<=20 and the paper certifies none.

Eq. (5), p.6: Hx=[Ha tensor I | I tensor Hb]; Hz=[I tensor Hb* | Ha* tensor I]. Star is matrix transpose together with x->x^-1. Implement cyclic binary blocks with polynomial row t supported at col(t+e mod p); changing both cyclic conventions by inversion is a qubit/check relabeling. Row/check ordering (i,j,t), column ordering left/right sectors, then (i,j,t). `prototype.py::cc_matrices` implements these directly. Candidate symmetries shift every t by s in every cluster; there are p-1 nonidentity candidates and all survived filtering in both bases (final local assertion); checks.json lists the Z-basis counts. The identity is deliberately filtered by from_row_perms. Rebuilt n,k and CSS conditions pass for all ten, row weights both types are uniformly 8.

`control24.json`: exact distance3 in both bases, with column-index witness [0,1,2]; every weight1/2 exhausted and witness zero syndrome/nonzero logical checked. With the stated ordering this is the entire first cluster, agreeing with the clustered logical basis Eq.(8) / Appendix I Eq.(I1).

## LLM BB 2606.02418

Sec III.1 Eq.(1): Hx=[A|B], Hz=[B^T|A^T], on Z_l x Z_m, exactly `stabcode.bb_matrices`. Shift convention and row ordering are the existing helper's i*m+j. Candidate symmetries are all torus translations (i,j)->(i+u,j+v).

The named [[360,12,d]] target is ambiguous: the paper gives both new non-CSS PBB [[360,12,<=24]] (main Table2) and CSS [[360,12,<=24]] (Supplemental I Table3 classV, rediscovered Bravyi code). The CSS instance is fully defined by l=30,m=6,A=y+y^2+x^9,B=y^3+x^25+x^26 and is included with d_claimed24 even though extra instances are restricted d<=20. Main Table5 explicitly distinguishes the two codes despite identical n,k,d_upper. No cited source is needed for the CSS generator definition because Supplemental Table3 supplies it.

Extra CSS open instances explicitly called upper bounds: [[360,20,<=14]], classWprime, and [[360,16,<=14]], classA. For classA use either Supplemental representative B=y^6+x^7+x^14 or main Table3's B=y^6+x^2+x^4; these share BLISS classA. The extraction chooses the first listed supplemental representation, without tuning.

Supplemental I Table3 supplies complete polynomial pairs for the additional n360 classes Yprime,Zprime,aprime,bprime,cprime,dprime,eprime,fprime,gprime,hprime with d<=20. That table does not give a per-row proven-optimal flag; its text says some Campaign4 rows are only MILP incumbents. These ten are conservatively labeled open because the paper does not explicitly certify them. `codes.json` records this status ambiguity per code. Supplemental Tables1 and2 captions explicitly say all n144/n288 distances are MILP exact, so those additional classes are excluded from the open-instance expansion. Classes U(d30) and Xprime(d22) exceed the further-instance distance cap.

Every included CSS construction rebuilt the stated n,k and passed all CSS commutation checks; checks.json contains parameters and row weights. Note classZprime has only 3+3 terms and row weight6; do not infer weight8 solely from Campaign4 affiliation. Classeprime has 5+5 terms and row weight10.

`excluded.json` records both exact four-polynomial non-CSS target definitions from main Table2. They rebuild [[360,12]] as general stabilizer codes, and have rank(X-support)=174, rank(Z-support)=322, stabilizer rank348. Since 174+322 !=348, their stabilizer groups are not CSS under row operations in the supplied physical basis. Pure CSS projection discarding C,D changes the code, even though its n,k coincides. Paper Appendix F identifies only 11 PBB entries with tested Clifford reductions, and neither target is among them. Representing these via the required `(hx,hz,n)` is unsupported; faithfully exclude with this interface limitation.

## Local commands and outcomes

- `curl -L --fail ... https://arxiv.org/pdf/2603.05398`: success, source PDF downloaded.
- `pdftotext -layout ...`: failed; executable absent.
- `curl -L --fail ... https://arxiv.org/html/2606.02418`: success, HTML downloaded.
- `OMP_NUM_THREADS=2 .venv/bin/python .../prototype.py`: first failed because venv Python lacks int.bit_count(); corrected to bin(r).count('1'). Second failed because supplemental table's actual DOM id suffix is .6; selected its observed prefix. Final run passed every n,k/CSS check and populated codes.json/checks.json.
- `OMP_NUM_THREADS=2 .venv/bin/python .../check_control.py`: passed, exact d3 in both bases and both witnesses validated.
- `OMP_NUM_THREADS=2 .venv/bin/python .../check_pbb.py`: passed both general stabilizer commutation and [[360,12]] dimension checks, and proved failure of group-CSS rank condition.
- `OMP_NUM_THREADS=2 .venv/bin/python` final inline assertion: all 10 QGPU codes have p-1 surviving cyclic symmetries in both bases; CSS named target V is present among 23 extracted records.
- HTML parsing using standard-library HTMLParser: success; no package installs.
- `swift .../render.swift ...`: failed to compile due installed Swift6.3.3 versus SDK Swift6.4 mismatch; no PDF image or full local PDF text was produced. QGPU extraction used arXiv web PDF text.
- `ls /opt/homebrew/bin/pdftoppm /usr/local/bin/pdftoppm /usr/bin/swift`: exit1; neither Poppler executable exists; Swift does exist.

No long/remote compute was run; no final shared files edited; no commits.
