import Foundation
import PDFKit
import AppKit
let doc = PDFDocument(url:URL(fileURLWithPath:CommandLine.arguments[1]))!
let page=doc.page(at:24)!
let rect=page.bounds(for:.mediaBox)
let image=page.thumbnail(of:NSSize(width:rect.width*2,height:rect.height*2),for:.mediaBox)
let data=NSBitmapImageRep(data:image.tiffRepresentation!)!.representation(using:.png,properties:[:])!
try! data.write(to:URL(fileURLWithPath:CommandLine.arguments[2]))
var text=""
for i in 0..<doc.pageCount {text += "\nPAGE \(i+1)\n" + (doc.page(at:i)?.string ?? "")}
try! text.write(toFile:CommandLine.arguments[3],atomically:true,encoding:.utf8)
