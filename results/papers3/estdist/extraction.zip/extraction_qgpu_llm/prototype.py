from pathlib import Path
import json, sys, re
sys.path.insert(0,str(Path.cwd()))
from papers import stabcode
from cdist import search, symmetry
OUT=Path('results/papers3/estdist/extraction_qgpu_llm')
# Table VI, k=8. Entries are lists of exponents of x.
QGPU=[
(24,8,3,3, [[[0,2],[1,2]],[[0,1],[1,2]]], [[[0,2],[1,2]],[[0,1],[0,1]]]),
(40,8,5,5, [[[1,3],[1,4]],[[1,4],[1,4]]], [[[0,1],[3,4]],[[0,4],[0,4]]]),
(56,8,7,7, [[[1,5],[1,3]],[[0,2],[0,3]]], [[[2,5],[0,1]],[[5,6],[4,6]]]),
(88,8,10,11, [[[1,5],[5,6]],[[2,3],[5,9]]], [[[0,3],[8,10]],[[5,7],[3,7]]]),
(104,8,11,13, [[[1,5],[2,5]],[[1,4],[9,10]]], [[[2,8],[0,8]],[[1,9],[1,3]]]),
(136,8,14,17, [[[13,16],[5,15]],[[6,16],[0,3]]], [[[1,7],[8,10]],[[8,10],[5,16]]]),
(54,18,3,3, [[[1,2],[],[0,1]],[[1,2],[0,1],[]],[[],[0,2],[0,2]]], [[[0,1],[0,2],[]],[[],[1,2],[0,2]],[[0,2],[],[1,2]]]),
(90,18,5,5, [[[0,1],[],[0,4]],[[0,3],[0,2],[]],[[],[0,4],[0,2]]], [[[0,4],[0,2],[]],[[],[0,3],[0,1]],[[0,1],[],[0,3]]]),
(126,18,7,7, [[[1,4],[],[2,4]],[[1,3],[2,5],[]],[[],[0,5],[0,3]]], [[[5,6],[5,6],[]],[[],[1,3],[0,1]],[[1,2],[],[4,6]]]),
(198,18,10,11, [[[4,9],[],[5,7]],[[4,6],[2,8],[]],[[],[7,10],[3,8]]], [[[3,4],[6,10],[]],[[],[2,3],[8,10]],[[0,7],[],[9,10]]]),
]
def cc_matrices(p,A,B):
 a,b=len(A),len(B); cells=a*b; half=cells*p; hx=[]; hz=[]
 for i in range(a):
  for j in range(b):
   for t in range(p):
    x=z=0
    for u in range(a):
     for e in A[i][u]: x^=1<<((u*b+j)*p+(t+e)%p)
     for e in A[u][i]: z^=1<<(half+(u*b+j)*p+(t-e)%p)
    for v in range(b):
     for e in B[j][v]: x^=1<<(half+(i*b+v)*p+(t+e)%p)
     for e in B[v][j]: z^=1<<((i*b+v)*p+(t-e)%p)
    hx.append(x); hz.append(z)
 return hx,hz,2*half

def cc_perms(p,A,B):
 cells=len(A)*len(B)
 return [[c*p+(t+s)%p for c in range(cells) for t in range(p)] for s in range(p)]

def parsepoly(s):
 s=s.replace('{+}','+').replace('{','').replace('}','')
 terms=[]
 for t in s.split('+'):
  a=re.search(r'x(?:\^(\d+))?',t); b=re.search(r'y(?:\^(\d+))?',t)
  terms.append([int(a[1] or 1) if a else 0,int(b[1] or 1) if b else 0])
 return terms
if __name__=='__main__':
 codes=[]; checked=[]
 for n,k,d,p,A,B in QGPU:
  name=f'qgpu_{n}_{k}_{d}'
  x,z,nn=cc_matrices(p,A,B); got=stabcode.css_parameters(x,z,nn); assert got==(n,k),(name,got)
  code={'name':name,'arxiv':'2603.05398','n':n,'k':k,'d_claimed':d,'status':'control' if n==24 else 'open','locator':'Table I; Appendix H, Table '+('VI' if k==8 else 'VII')+'; Eq. (5); Appendix F Table IV','kind':'cc','p':p,'A':A,'B':B}
  codes.append(code)
  pp=stabcode.css_distance_problem(x,z,nn,'Z',name); sym=symmetry.from_row_perms(pp,cc_perms(p,A,B))
  checked.append({'name':name,'parameters':got,'row_weights_x':sorted(set(bin(r).count("1") for r in x)),'row_weights_z':sorted(set(bin(r).count("1") for r in z)),'symmetries':len(sym.get('generators',[]))})
 tables=json.loads((OUT/'llm_tables.json').read_text()); tab=[t for t in tables if t['id'] and t['id'].startswith('as1_S1.T3.')][0]
 seen=set()
 for row in tab['rows'][1:]:
  if len(row)!=12: continue
  cl,lattice,aa,bb,k,d,_,_,_,_,_,campaign=[c['text'].strip() for c in row]
  if not (campaign=='A' or cl=='A'): continue
  if not d.isdigit() or (int(d)>20 and cl!='V†') or cl in seen: continue
  seen.add(cl); l,m=map(int,re.findall(r'\d+',lattice)); A=parsepoly(aa); B=parsepoly(bb)
  name=f'llmbb_360_{k}_{d}_{cl.replace(chr(8242),"prime").replace(chr(8224),"")}'
  x,z,n=stabcode.bb_matrices(l,m,A,B); got=stabcode.css_parameters(x,z,n); assert got==(n,int(k)),(name,got)
  code={'name':name,'arxiv':'2606.02418','n':n,'k':int(k),'d_claimed':int(d),'status':'open','locator':f'Supplemental Material I Table 3 class {cl}; Eq. (1)','kind':'bb','l':l,'m':m,'A':A,'B':B,'status_note':'Explicit upper bound in main text' if cl in ('A','W′') else 'Supplement table provides MILP value without an optimality certificate; conservatively open'}
  codes.append(code); checked.append({'name':name,'parameters':got,'row_weights_x':sorted(set(bin(r).count("1") for r in x)),'row_weights_z':sorted(set(bin(r).count("1") for r in z))})
 (OUT/'codes.json').write_text(json.dumps(codes,indent=2)); (OUT/'checks.json').write_text(json.dumps(checked,indent=2)); print(json.dumps(checked,indent=2))
