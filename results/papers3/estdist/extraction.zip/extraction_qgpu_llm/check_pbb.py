from prototype import *
excluded=[]
for d,A,B,C,D in [
(24,[[1,2],[4,3],[4,4]],[[0,0],[1,5],[5,4]],[[1,0],[4,0]],[[1,2],[4,2]]),
(20,[[13,4],[22,2],[22,3]],[[0,0],[5,2],[13,1]],[[13,3],[22,3]],[[13,1],[22,1]])]:
 hx,hz,n=stabcode.bb_matrices(30,6,A,B); cd,_,_=stabcode.bb_matrices(30,6,C,D)
 stabs=[x|(z<<n) for x,z in zip(hx,cd)]+[z<<n for z in hz]
 params=stabcode.stabilizer_parameters(stabs,n); assert params==(360,12),params
 rankx=stabcode.rank(hx); rankz=stabcode.rank(cd+hz); rankstab=stabcode.rank(stabs)
 assert rankx+rankz>rankstab
 ex={'arxiv':'2606.02418','n':360,'k':12,'d_claimed':d,'l':30,'m':6,'A':A,'B':B,'C':C,'D':D,'locator':'Main Table 2; Sec III.2 Eq.(2); Appendix F','reason':'Fully specified non-CSS PBB; the CSS-only matrices interface does not represent its mixed stabilizers. Projecting to A,B would discard C,D and change the code.','rebuilt_parameters':params,'rank_xblock':rankx,'rank_zblock':rankz,'rank_stabilizer':rankstab,'group_css':False}
 excluded.append(ex)
(OUT/'excluded.json').write_text(json.dumps(excluded,indent=2)); print(json.dumps(excluded,indent=2))
