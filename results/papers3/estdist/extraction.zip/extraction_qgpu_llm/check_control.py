import json,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'results/papers3/estdist/extraction_qgpu_llm'))
from prototype import *
n,k,d,p,A,B=QGPU[0]; hx,hz,n=cc_matrices(p,A,B); out={}
for basis in 'ZX':
 pp=stabcode.css_distance_problem(hx,hz,n,basis,'qgpu24')
 sy=symmetry.from_row_perms(pp,cc_perms(p,A,B))
 r=search.distance(pp,k_table=2,kmax=3,cover=True,time_limit=10,rank=sy['rank'],anchors=sy['anchors'])
 for sol in r['solutions']:
  h=l=0
  for c in sol: h^=pp.h[c]; l^=pp.l[c]
  assert h==0 and l!=0 and len(sol)==3
 out[basis]=r
(OUT/'control24.json').write_text(json.dumps(out,indent=2)); print(out)
