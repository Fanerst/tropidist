from html.parser import HTMLParser
from pathlib import Path
import json
class Parser(HTMLParser):
 def __init__(self):
  super().__init__(); self.tables=[]; self.table=None; self.cell=None; self.row=None; self.math=0
 def handle_starttag(self,t,a):
  a=dict(a)
  if t=='table': self.table={'id':a.get('id'),'rows':[]}; self.tables.append(self.table)
  if t=='tr' and self.table is not None: self.row=[]; self.table['rows'].append(self.row)
  if t in ('td','th') and self.row is not None: self.cell={'text':'','bold':False}; self.row.append(self.cell)
  if self.cell is not None:
   if 'ltx_font_bold' in a.get('class',''): self.cell['bold']=True
   if t=='math': self.math+=1; self.cell['text']+=a.get('alttext','')
 def handle_endtag(self,t):
  if t=='math' and self.math: self.math-=1
  if t in ('td','th'): self.cell=None
  if t=='tr': self.row=None
  if t=='table': self.table=None
 def handle_data(self,d):
  if self.cell is not None and not self.math: self.cell['text']+=d
p=Parser(); p.feed(Path('results/papers3/estdist/extraction_qgpu_llm/llm.html').read_text())
Path('results/papers3/estdist/extraction_qgpu_llm/llm_tables.json').write_text(json.dumps(p.tables,indent=2))
for ti,t in enumerate(p.tables):
 if t['rows'] and len(t['rows'][0])==12:
  print('TABLE',ti,t['id'])
  for r in t['rows']:
   if len(r)==12 and (not r[5]['bold']): print([c['text'].strip() for c in r])
